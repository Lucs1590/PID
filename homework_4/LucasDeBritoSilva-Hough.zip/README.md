# Transformada de Hough Generalizada
## Pré-requisitos
 - Python 3.6 ou superior
 - Bibliotecas do requirements

## Como instalar
```
pip3 install -r requirements.txt
```

## Como executar
```
python3 src/main.py
```
